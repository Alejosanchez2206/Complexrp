const generarId = () => {
    const timestamp = Date.now().toString();
    const letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const numeros = timestamp.slice(-5);
    const generarLetra = () => letras[Math.floor(Math.random() * letras.length)];
    const id = Array(5).fill(null).map(generarLetra).join('') + numeros;
    return id;
};

module.exports = { generarId };  
